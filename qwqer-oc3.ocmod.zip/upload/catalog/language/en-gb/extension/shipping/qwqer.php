<?php
// Text

$_['text_title']            = 'Qwqer service';
$_['text_title_standart']   = 'Standart Qwqer Shipping Service';
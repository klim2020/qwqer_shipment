<?php
// Text

$_['text_title']            = 'Служба доставки service';
$_['text_title_standart']   = 'Доставка Qwqer: Стандарт';
<?php
// Text

$_['text_title']            = 'Qwqer pakalpojums';
$_['text_title_standart']   = 'Standart Qwqer nosūtīšanas pakalpojums';
<?php
// Text

$_['text_title']                       = 'Доставка QWQER';

$_['text_title_ScheduledDelivery']     = 'QWQER Курьер сегодня вечером (18:00 - 22:00)';
$_['text_title_ExpressDelivery']       = 'QWQER Экспресс (90 мин)';
$_['text_title_OmnivaParcelTerminal']  = 'QWQER Почтомат сегодня вечером (18:00–22:00)';

$_['text_select_box']                  = 'Введите адрес или идентификатор';

$_['message_status_order_success']     = 'QWEQR Статус: ✅ Заказ успешно создан';
$_['message_status_order_error']       = 'QWEQR Статус: ❌ Заказ не был создан';
$_['message_status_order_id']          = 'Сообщение от сервера';
<?php
// Text

$_['text_title']                       = 'Доставка QWQER';

$_['text_title_ScheduledDelivery']     = 'Обычная доставка';
$_['text_title_ExpressDelivery']       = 'Экспресс -доставка';
$_['text_title_OmnivaParcelTerminal']  = 'Доставка через терминал';

$_['text_select_box']                  = 'Введите адрес или идентификатор';

$_['message_status_order_success']     = 'QWEQR Статус: ✅ Заказ успешно создан';
$_['message_status_order_error']       = 'QWEQR Статус: ❌ Заказ не был создан';
$_['message_status_order_id']          = 'Сообщение от сервера';
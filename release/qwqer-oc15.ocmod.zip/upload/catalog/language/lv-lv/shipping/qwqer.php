<?php
// Text

$_['text_title']                       = 'QWQER piegāde';

$_['text_title_ScheduledDelivery']     = 'Vakara piegāde';
$_['text_title_ExpressDelivery']       = 'Ekspress piegāde';
$_['text_title_OmnivaParcelTerminal']  = 'Piegāde uz pakomātu (Omniva)';

$_['text_select_box']                  = 'Ievadiet adresi vai ID';

$_['message_status_order_success']     = 'QWEQR statuss: ✅ Pasūtījums tika veiksmīgi izveidots';
$_['message_status_order_error']       = 'QWEQR statuss: ❌ Pasūtījums netika izveidots';
$_['message_status_order_id']          = 'Ziņojums no servera:';
<?php
// Text

$_['text_title']                       = 'QWQER delivery';

$_['text_title_ScheduledDelivery']     = 'Sheduled delivery';
$_['text_title_ExpressDelivery']       = 'Express delivery';
$_['text_title_OmnivaParcelTerminal']  = 'Omnival Parcel Terminal';

$_['text_select_box']                  = 'Enter Address or Id';

$_['message_status_order_success']     = 'QWQER Status: ✅ Order created successfully';
$_['message_status_order_error']       = 'QWQER Status: ❌ Order was not created';
$_['message_status_order_id']          = 'Message from server is:';
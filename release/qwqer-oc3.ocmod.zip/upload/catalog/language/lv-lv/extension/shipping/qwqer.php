<?php
// Text

$_['text_title']                         = 'QWQER piegāde';
$_['text_title_ScheduledDelivery']       = 'Šovakar (18:00-22:00)';
$_['text_title_ExpressDelivery']         = 'Ekspress (90 min)';
$_['text_title_OmnivaParcelTerminal']    = 'Omniva pakomāts šovakar (18:00-22:00)';
$_['text_select_box']                    = 'Ievadiet adresi vai identifikātoru';
$_['message_status_order_success']       = 'QWQER status: ✅ Pasūtījums tika veiksmīgi izveidots';
$_['message_status_order_error']         = 'QWQER Status: ❌ Pasūtījumu neizdevās izveidot';
$_['message_status_order_id']            = 'Atbilde no servera:';
$_['text_full_name']                     = 'Pilns vārds';
$_['text_select_city']                   = 'Izvēlieties pilsētu';
$_['text_telephone']                     = 'Ievadiet tālruņa numuru';
$_['text_test']                          = 'Ievadiet tālruņa numuru';
$_['text_name']                          = 'Vārds';
$_['text_phone']                         = 'Telefona numurs';
$_['text_address']                       = 'Adrese';
$_['text_price']                         = 'Cena';
$_['qw_text_name_req']                   = 'Ievadiet pilnu vārdu';
$_['qw_text_phone_req']                  = 'Ievadiet adresi';
$_['qw_text_address_req']                = 'Nepieciešams telefona numurs ar Latvijas valsts kodu (+371)';
$_['qw_text_server_error']               = 'Servera kļūda, lūdzu, mēģiniet vēlreiz';
$_['qw_enter_phone_label']               = 'Norādiet telefonan numuru';
$_['qw_text_submit']                     = 'Iesniegt';
$_['qw_text_submit_success']             = 'Visi dati ir derīgi';
$_['qw_text_select_city']                = 'Lūdzu, izvēlieties pilsētu';
$_['qw_text_loading']                    = 'Ielādējas...';

$_['qw_text_noopts']                    = 'Nav variantu';
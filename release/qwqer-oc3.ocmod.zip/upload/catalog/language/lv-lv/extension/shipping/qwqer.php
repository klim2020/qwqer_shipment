<?php
// Text

$_['text_title']                       = 'QWQER piegāde';

$_['text_title_ScheduledDelivery']     = 'QWQER kurjers šovakar (18:00 - 22:00)';
$_['text_title_ExpressDelivery']       = 'QWQER Express (90 min)';
$_['text_title_OmnivaParcelTerminal']  = 'QWQER pakomāts šovakar (18:00 - 22:00)';

$_['text_select_box']                  = 'Ievadiet adresi vai ID';

$_['message_status_order_success']     = 'QWEQR statuss: ✅ Pasūtījums tika veiksmīgi izveidots';
$_['message_status_order_error']       = 'QWEQR statuss: ❌ Pasūtījums netika izveidots';
$_['message_status_order_id']          = 'Ziņojums no servera:';
<?php
// Text
$_['text_title']    = 'Qwqer service';